(** Order: Simon Huang (mh954), Zhaojiahong Zhu (zz264), Emily Bai
    (sb875), Qingyang Ren (qr23) *)
let hours_worked = [ 8; 8; 12; 12 ]
